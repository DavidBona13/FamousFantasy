package com.example.famousfantasy_1.database

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.Inicio
import com.example.famousfantasy_1.R

class Registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registro)

        val etNombre = findViewById<EditText>(R.id.et_user)
        val etMail = findViewById<EditText>(R.id.id_mail)
        val etUsuario = findViewById<EditText>(R.id.et_usuario)
        val etPass = findViewById<EditText>(R.id.id_pass)

        val btnAddUser = findViewById<Button>(R.id.btn_crear)


        btnAddUser.setOnClickListener {

            val admin = BaseDatosApp(this, "bd", null, 1)
            val bd = admin.writableDatabase
            val reg = ContentValues()

            //reg.put("ID", 1)
            reg.put("NOMBRE", etNombre.text.toString())
            reg.put("MAIL", etMail.text.toString())
            reg.put("NOMBRE_USER", etUsuario.text.toString())
            reg.put("PASSWORD", etPass.text.toString())

            bd.insert("Usuarios", null, reg)
            bd.close()
            Toast.makeText(this, "Registrando usuario...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, Inicio::class.java)
            startActivity(intent)
        }
    }

}