package com.example.famousfantasy_1.ui.slideshow

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.databinding.FragmentSlideshowBinding

class SlideshowFragment : Fragment() {
    private var binding: FragmentSlideshowBinding? = null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val slideshowViewModel = ViewModelProvider(this).get(
            SlideshowViewModel::class.java
        )
        binding = FragmentSlideshowBinding.inflate(inflater, container, false)
        val root: View = binding!!.root
        val textView = binding!!.textViewResumenConfiguracion
        val buttonGuardar = binding!!.botonGuardar

        // Configurar el texto
        textView.text =
            "Bienvenido a Famous Fantasy, tu destino definitivo para vivir la emoción de cotillear a los famosos de una manera única y emocionante. Somos un equipo apasionado de desarrolladores y aficionados a los famosos, que se han unido para crear una experiencia de juego inigualable. Nuestra misión es llevar la pasión que tenemos hacia los famosos más allá de los límites de la cámara y poder brindar una experiencia interactiva que te sumerja por completo en el emocionante mundo del famous fantasy. Queremos que cada usuario se sienta parte de algo más grande, conectando con otros amantes de todo el mundo. La transparencia y la equidad son fundamentales para nosotros, y nos esforzamos por construir una comunidad en la que todos los jugadores se sientan valorados. También dependemos de un equipo apasionado de desarrolladores, diseñadores y amantes a los famosos, que trabajan incansablemente para mejorar y expandir continuamente la plataforma. ¡Construyamos juntos momentos inolvidables, estrategias ingeniosas y competiciones emocionantes en Famous Fantasy!"

        // Configurar el botón
        buttonGuardar.setOnClickListener { launchGeneralActivity() }
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    // Método para la acción del botón (puedes ajustar esto según tus necesidades)
    private fun launchGeneralActivity() {
        val intent = Intent(activity, MainActivity::class.java)
        startActivity(intent)
    }
}