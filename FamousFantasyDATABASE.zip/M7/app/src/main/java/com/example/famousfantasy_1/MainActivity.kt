package com.example.famousfantasy_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.general)

        val boton1: ImageButton = findViewById(R.id.imageButton1)
        boton1.setOnClickListener {
            val notificacion = Toast.makeText(this@MainActivity, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }

        val button2: Button = findViewById(R.id.button4)
        val button3: Button = findViewById(R.id.button5)
        val button4: Button = findViewById(R.id.button6)
        val button5: Button = findViewById(R.id.button7)


        button2.setOnClickListener{
            lanzarEquipo(it)
        }

        button3.setOnClickListener{
            lanzarMercado(it)
        }

        button4.setOnClickListener{
            lanzarTabla(it)
        }

        button5.setOnClickListener{
            lanzarMas(it)
        }

    }

    fun lanzarEquipo(view: View){
        val intent = Intent(this, Equipo::class.java)
        startActivity(intent)
    }

    fun lanzarMercado(view: View){
        val intent = Intent(this, Mercado::class.java)
        startActivity(intent)
    }

    fun lanzarTabla(view: View){
        val intent = Intent(this, Tabla::class.java)
        startActivity(intent)
    }

    fun lanzarMas(view: View){
        val intent = Intent(this, Mas::class.java)
        startActivity(intent)
    }
}