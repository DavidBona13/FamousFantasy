package com.example.famousfantasy_1.ui.gallery

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.R
import com.example.famousfantasy_1.databinding.FragmentGalleryBinding

class GalleryFragment : Fragment() {
    private var galleryViewModel: GalleryViewModel? = null
    private var binding: FragmentGalleryBinding? = null
    private var textViewResumenConfiguracion: TextView? = null // Nuevo TextView
    private val checkBoxNotificaciones: CheckBox? = null
    private val seekBarVolumen: SeekBar? = null
    private val spinnerIdioma: Spinner? = null
    private var botonGuardar: Button? = null

    // New elements added from fragment_gallery.xml
    private var switchModoAvion: Switch? = null
    private var switchOpcion1: Switch? = null
    private var switchOpcion2: Switch? = null
    private var radioGroupOpciones: RadioGroup? = null
    private var radioOpcion1: RadioButton? = null
    private var radioOpcion2: RadioButton? = null
    private var editTextNombreUsuario: EditText? = null
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        galleryViewModel = ViewModelProvider(this).get(GalleryViewModel::class.java)
        binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding!!.root
        initializeViews(root)
        setupListeners()
        return root
    }

    private fun initializeViews(root: View) {
        textViewResumenConfiguracion = root.findViewById(R.id.textViewResumenConfiguracion)
        botonGuardar = root.findViewById(R.id.botonGuardar)

        // Initialize new elements
        switchModoAvion = root.findViewById(R.id.switchModoNocturno)
        switchOpcion1 = root.findViewById(R.id.switchOpcion1)
        switchOpcion2 = root.findViewById(R.id.switchOpcion2)
        radioGroupOpciones = root.findViewById(R.id.radioGroupOpciones)
        radioOpcion1 = root.findViewById(R.id.radioOpcion1)
        radioOpcion2 = root.findViewById(R.id.radioOpcion2)
        editTextNombreUsuario = root.findViewById(R.id.editTextNombreUsuario)
    }

    private fun setupListeners() {
        val textView = binding!!.textViewResumenConfiguracion
        galleryViewModel!!.text.observe(viewLifecycleOwner) { text: CharSequence? ->
            textView.text = text
        }

        // Add listeners for new elements as needed
        switchModoAvion!!.setOnCheckedChangeListener { buttonView: CompoundButton?, isChecked: Boolean -> }
        switchOpcion1!!.setOnCheckedChangeListener { buttonView: CompoundButton?, isChecked: Boolean -> }
        switchOpcion2!!.setOnCheckedChangeListener { buttonView: CompoundButton?, isChecked: Boolean -> }

        // Add listeners for radio buttons if needed
        radioGroupOpciones!!.setOnCheckedChangeListener { group: RadioGroup?, checkedId: Int -> }

        // Add listener for editTextNombreUsuario if needed
        editTextNombreUsuario!!.setOnEditorActionListener { v: TextView?, actionId: Int, event: KeyEvent? -> false }
        botonGuardar!!.setOnClickListener { // Aquí es donde inicias la actividad General
            launchGeneralActivity()
        }


        // Add listeners for other elements as needed
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }

    private fun launchGeneralActivity() {
        // Aquí deberías tener la lógica para iniciar la actividad General
        // Por ejemplo:
        val intent = Intent(activity, MainActivity::class.java)
        startActivity(intent)
    }
}