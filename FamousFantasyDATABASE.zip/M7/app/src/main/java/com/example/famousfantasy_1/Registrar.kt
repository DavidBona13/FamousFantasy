package com.example.famousfantasy_1

class Registrar {
}