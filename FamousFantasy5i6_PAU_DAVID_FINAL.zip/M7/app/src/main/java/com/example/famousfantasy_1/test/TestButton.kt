package com.example.famousfantasy_1.test
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.R
import com.example.famousfantasy_1.database.Registro
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
class TestButton {
    @get:Rule
    val activityScenarioRule = ActivityScenarioRule(MainActivity::class.java)
    @Test
    fun testButton04Text() {
        val expectedButtonText = "Equipo"

        // Obtener la actividad actual del escenario
        activityScenarioRule.scenario.onActivity { activity ->
            // Encontrar el botón con ID button04
            val button = activity.findViewById<Button>(R.id.button4)
            assertNotNull(button)

            // Verificar que el texto del botón sea el esperado
            assertEquals(expectedButtonText, button.text.toString())
        }
    }
}