package com.example.famousfantasy_1.ui.slideshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SlideshowViewModel : ViewModel() {
    private val mText: MutableLiveData<String>

    init {
        mText = MutableLiveData()
        mText.value = """
            Bienvenido a Famous Fantasy, tu destino definitivo para vivir la emoción de cotillear a los famosos de una manera única y emocionante.
            Somos un equipo apasionado de desarrolladores y aficionados a los famosos, que se han unido para crear una experiencia de juego inigualable.
            Nuestra misión, es llevar la pasión que tenemos hacia los famosos más allá de los límites de la cámara y poder brindar una experiencia interactiva que te sumerja por completo en el emocionante mundo del famous fantasy.
            Queremos que cada usuario se sienta parte de algo más grande, conectando con otros amantes de todo el mundo.
            La transparencia y la equidad son fundamentales para nosotros, y nos esforzamos por construir una comunidad en la que todos los jugadores se sientan valorados.
            También dependemos de un equipo apasionado de desarrolladores, diseñadores y amantes a los famosos, que trabajan incansablemente para mejorar y expandir continuamente la plataforma.
            ¡Construyamos juntos momentos inolvidables, estrategias ingeniosas y competiciones emocionantes en Famous Fantasy!
            """.trimIndent()
    }

    val text: LiveData<String>
        get() = mText
}