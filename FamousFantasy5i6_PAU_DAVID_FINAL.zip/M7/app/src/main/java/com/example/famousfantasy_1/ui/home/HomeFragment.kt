package com.example.famousfantasy_1.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private var binding: FragmentHomeBinding? = null
    private var textViewResumenConfiguracion: TextView? = null // Nuevo TextView
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val homeViewModel = ViewModelProvider(this).get(
            HomeViewModel::class.java
        )
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding!!.root

        // Enlace de vistas con el layout
        val checkBoxNotificaciones = binding!!.checkBoxNotificaciones
        val seekBarVolumen = binding!!.seekBarVolumen
        val radioOpcion1 = binding!!.radioOpcion1
        val radioOpcion2 = binding!!.radioOpcion2
        val switchModoNocturno = binding!!.switchModoNocturno
        val editTextNombreUsuario = binding!!.editTextNombreUsuario
        val botonGuardar = binding!!.botonGuardar
        textViewResumenConfiguracion = TextView(activity) // Inicialización del TextView

        // Agregar el TextView al layout
        val params = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        (root as ViewGroup).addView(textViewResumenConfiguracion, params)
        switchModoNocturno.isChecked = true // Puedes ajustar esto según tus necesidades
        // Ejemplo de escucha de cambios en el SeekBar
        seekBarVolumen.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Hacer algo cuando cambia el progreso
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Hacer algo cuando se toca el SeekBar
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Hacer algo cuando se deja de tocar el SeekBar
            }
        })
        botonGuardar.setOnClickListener { // Aquí es donde inicias la actividad General
            launchGeneralActivity()
        }

        // Puedes agregar más lógica según sea necesario
        return root
    }

    // Método para iniciar la actividad General
    private fun launchGeneralActivity() {
        // Aquí deberías tener la lógica para iniciar la actividad General
        // Por ejemplo:
        val intent = Intent(activity, MainActivity::class.java)
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}