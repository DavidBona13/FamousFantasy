package com.example.famousfantasy_1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Clasificacion_semanal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.clasificacion_semanal)

    }
}