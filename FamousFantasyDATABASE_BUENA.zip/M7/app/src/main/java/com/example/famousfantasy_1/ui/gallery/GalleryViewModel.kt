package com.example.famousfantasy_1.ui.gallery

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GalleryViewModel : ViewModel() {
    private val mText: MutableLiveData<String>

    init {
        mText = MutableLiveData()
        mText.value =
            "Esta es la interfaz de configuración para usuario la cual que nos permite: activar/desactivar el compartir datos, activar/desactivar privacidad de datos, activar/desactivar zona horaria, modificar opciones de generar contraseña, ingresar consultas al soporte para usuario y guardar la configuración."
    }

    val text: LiveData<String>
        get() = mText
}