package com.example.famousfantasy_1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Tabla : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tabla)
        val boton7: ImageButton = findViewById(R.id.imageButton1)
        boton7.setOnClickListener {
            val notificacion = Toast.makeText(this@Tabla, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }
        val button1: Button = findViewById(R.id.btn_iniciar_sesion)
        val button2: Button = findViewById(R.id.button4)
        val button3: Button = findViewById(R.id.button5)
        val button4: Button = findViewById(R.id.button7)
        val button5: Button = findViewById(R.id.button9)
        val button6: Button = findViewById(R.id.button10)

        button1.setOnClickListener{
            lanzarGeneral(it)
        }

        button2.setOnClickListener{
            lanzarEquipo(it)
        }

        button3.setOnClickListener{
            lanzarMercado(it)
        }

        button4.setOnClickListener{
            lanzarMas(it)
        }
        button5.setOnClickListener {
            lanzarClasificacionSemanal(it)
        }

        button6.setOnClickListener{
            lanzarClasificacionGeneral(it)
        }

    }

    fun lanzarGeneral(view: View){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun lanzarEquipo(view: View){
        val intent = Intent(this, Equipo::class.java)
        startActivity(intent)
    }

    fun lanzarMercado(view: View){
        val intent = Intent(this, Mercado::class.java)
        startActivity(intent)
    }

    fun lanzarMas(view: View){
        val intent = Intent(this, Mas::class.java)
        startActivity(intent)
    }

    fun lanzarClasificacionGeneral(view: View){
        val intent = Intent(this, Clasificacion_general::class.java)
        startActivity(intent)
    }

    fun lanzarClasificacionSemanal(view: View){
        val intent = Intent(this, Clasificacion_semanal::class.java)
        startActivity(intent)
    }
}