package com.example.famousfantasy_1.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BaseDatosApp(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int)
    : SQLiteOpenHelper(context, name, factory, version) {

    override fun onCreate(database: SQLiteDatabase?) {
        val create_users_table = "CREATE TABLE Usuarios " +
                "(ID INT PRIMARY KEY ," +
                "NOMBRE TEXT, " +
                "MAIL TEXT, " +
                "NOMBREUSER TEXT, " +
                "PASSWORD TEXT)"

        val insert_data_table_user = "INSERT INTO Usuarios(ID, NOMBRE, MAIL, NOMBREUSER, PASSWORD) VALUES (1, 'Daniel', 'Danielrb@gmail.com', 'dani721tiger' '1234')"

        val create_famosos_fichados ="CREATE TABLE FamososFichados" +
                "(ID INT PRIMARY KEY, " +
                "NOMBRE TEXT, " +
                "DATOS TEXT, " +
                "VALOR TEXT, " +
                "IMAGEN_RUTA TEXT, " +
                "DESCRIPCION_IMAGEN TEXT)"

        //val rutaImagen = "/ruta/a/la/imagen.png"
        //val descripcion = "Imagen de ejemplo"
        //val insert_data_table_famosos_fichados = "INSERT INTO FamososFichados(ID, NOMBRE, DATOS, VALOR, IMAGEN_RUTA,DESCRIPCION_RUTA) VALUES (1, 'Mister Tartaria', 'Versiones por el espacio tiempo', '12.6M', " + "'" + rutaImagen +"', " + "'"+ descripcion+"' )"

        val create_famosos_mercado ="CREATE TABLE FamososMercado" +
                "(ID INT PRIMARY KEY AUTOINCREMENT, " +
                "NOMBRE TEXT, " +
                "DATOS TEXT, " +
                "VALOR DOUBLE, " +
                "IMAGEN_RUTA TEXT, " +
                "DESCRIPCION_IMAGEN TEXT)"

        val rutaImagen = "/ruta/a/la/imagen.png"
        val descripcion = "Imagen de ejemplo"

        val insert_data_table_famosos_mercado = "INSERT INTO FamososFichados(ID, NOMBRE, DATOS, VALOR, IMAGEN_RUTA,DESCRIPCION_RUTA) VALUES (1, 'Mister Tartaria', 'Superviviente del reset del ¿1798?', 12.6, " + "'" + rutaImagen +"', " + "'"+ descripcion+"' )"

        val create_valor = "CREATE TABLE Valor" +
                "(ID INT PRIMARY KEY, " +
                "VALOR_GENERAL DOUBLE)"

        val insert_data_table_valor ="INSERT INTO Valor(ID, VALOR_GENERAL) VALUES (1, 24.8)"

        if (database != null) {
            database.execSQL(create_users_table)
        }
        if (database != null) {
            database.execSQL(create_famosos_mercado)
        }
        if (database != null) {
            database.execSQL(create_valor)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }
}