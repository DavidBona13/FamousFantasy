package com.example.famousfantasy_1.Data

import android.widget.Button

data class Tarea (
    val id: Int,
    val foto: Int,
    val famoso: String,
    val datos: String,
    val valor: String,
    val valorDatos: String,
    val valorValor: String,
    val flecha: Int,
    val mostrarButton : Boolean
    )