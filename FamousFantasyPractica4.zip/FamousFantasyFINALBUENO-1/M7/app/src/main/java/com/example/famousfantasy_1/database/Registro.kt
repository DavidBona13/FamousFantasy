package com.example.famousfantasy_1.database

import android.content.ContentValues
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.R

class Registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registro)

    }

    fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView: View = inflater.inflate(R.layout.registro, container, false)

        val etNombre = rootView.findViewById<EditText>(R.id.editTextText)
        val etMail = rootView.findViewById<EditText>(R.id.editTextTextEmailAddress)
        val etUsuario = rootView.findViewById<EditText>(R.id.editTextText2)
        val etPass = rootView.findViewById<EditText>(R.id.editTextTextPassword2)

        val btnAddUser = rootView.findViewById<Button>(R.id.button)

        btnAddUser.setOnClickListener {

            val admin = BaseDatosApp(this, "bd", null, 1)
            val bd = admin.writableDatabase
            val reg = ContentValues()

            reg.put("ID", 1)
            reg.put("NOMBRE", etNombre.text.toString())
            reg.put("MAIL", etMail.text.toString())
            reg.put("NOMBREUSER", etUsuario.text.toString())
            reg.put("PASSWORD", etPass.text.toString())

            bd.insert("Usuarios", null, reg)
            bd.close()
        }

        return rootView
    }

}