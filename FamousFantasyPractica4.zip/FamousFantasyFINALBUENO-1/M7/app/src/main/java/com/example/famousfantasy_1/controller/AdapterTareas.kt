package com.example.famousfantasy_1.controller

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.famousfantasy_1.Data.Tarea
import com.example.famousfantasy_1.R

class AdapterTareas(private val tareasList: ArrayList<Tarea>) : RecyclerView.Adapter<AdapterTareas.ViewHolder>() {

    lateinit var context : Context

    fun obtenerContext(): Context {
        return context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_tareas_list, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return tareasList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int){
        val tarea = tareasList[position]
        holder.idTarea = tarea.id
        holder.fotoTarea1.setImageResource(tarea.foto)
        holder.tareaFamosoName.text = tarea.famoso
        holder.tareaDatos.text = tarea.datos
        holder.tareaValor.text = tarea.valor
        holder.valorDatosTarea.text = tarea.valorDatos
        holder.valorValorTarea.text  = tarea.valorValor
        holder.flechaImg.setImageResource(tarea.flecha)

        if (tarea.mostrarButton == true) {
            holder.ficharTarea.visibility = View.VISIBLE
        } else {
            holder.ficharTarea.visibility = View.GONE
        }
        //holder.ficharTarea.setOnClickListener()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

        var idTarea : Int = 0
        var fotoTarea1 : ImageView = itemView.findViewById(R.id.iv_foto)
        var tareaFamosoName : TextView = itemView.findViewById(R.id.tv_famoso)
        var tareaDatos : TextView = itemView.findViewById(R.id.tv_datos)
        var tareaValor : TextView = itemView.findViewById(R.id.tv_valor)
        var valorDatosTarea : TextView = itemView.findViewById(R.id.tv_valor_datos)
        var valorValorTarea : TextView = itemView.findViewById(R.id.tv_valor_valor)
        var flechaImg : ImageView = itemView.findViewById(R.id.iv_flecha)
        var ficharTarea : Button = itemView.findViewById(R.id.b_fichar)

    }
}