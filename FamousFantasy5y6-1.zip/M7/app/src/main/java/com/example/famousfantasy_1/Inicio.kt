package com.example.famousfantasy_1

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.database.BaseDatosApp

class Inicio : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.inicio)

        val btnIniciar : Button = findViewById(R.id.btn_iniciar_sesion)
    }

    fun iniciarSesion(view: View) {
        val etUsuario : EditText = findViewById(R.id.et_user)
        val etPassword : EditText = findViewById(R.id.et_password)

        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.writableDatabase
        val fila = bd.rawQuery("SELECT NOMBRE_USER, PASSWORD FROM Usuarios WHERE NOMBRE='${etUsuario.text.toString()}' AND PASSWORD='${etPassword.text.toString()}'", null)
        var user = ""
        var password = ""
        if(fila.moveToFirst()){
            user = fila.getString(0)
            password = fila.getString(1)
        }

        if(etUsuario.toString() == "Daniel") {
            if(etPassword.toString() == "1234"){
                Toast.makeText(this, "Iniciando sesion...", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
        }

    }

}