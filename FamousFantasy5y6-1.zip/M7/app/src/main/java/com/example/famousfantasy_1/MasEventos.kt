package com.example.famousfantasy_1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MasEventos: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mas_eventos)

        val boton7: ImageButton = findViewById(R.id.imageButton1)
        boton7.setOnClickListener {
            val notificacion = Toast.makeText(this@MasEventos, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }

    }
}