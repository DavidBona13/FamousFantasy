package com.example.famousfantasy_1.ui.gallery


import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.famousfantasy_1.R
import com.example.famousfantasy_1.database.BaseDatosApp
import com.example.famousfantasy_1.databinding.FragmentGalleryBinding
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class GalleryFragment : Fragment() {
    private var galleryViewModel: GalleryViewModel? = null
    private var binding: FragmentGalleryBinding? = null
    private var textViewResumenConfiguracion: TextView? = null
    private var botonInforme: Button? = null
    private var radioOpcion2: RadioButton? = null

    companion object {
        private const val PERMISSION_REQUEST_CODE = 1
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        galleryViewModel = ViewModelProvider(this).get(GalleryViewModel::class.java)
        binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding!!.root
        initializeViews(root)
        setupListeners()
        return root
    }

    @SuppressLint("Range")
    private fun generarInformePDF() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE)
        } else {
            try {
                val admin = BaseDatosApp(requireContext(), "bd", null, 1)
                val db = admin.readableDatabase

                val cursor = db.rawQuery("SELECT * FROM Usuarios", null)
                val usuarios = StringBuilder()
                while (cursor.moveToNext()) {
                    val nombre = cursor.getString(cursor.getColumnIndex("NOMBRE"))
                    val mail = cursor.getString(cursor.getColumnIndex("MAIL"))
                    val nombreUsuario = cursor.getString(cursor.getColumnIndex("NOMBRE_USER"))
                    usuarios.append("Nombre: $nombre, Email: $mail, Usuario: $nombreUsuario\n")
                }
                cursor.close()
                db.close()

                if (isExternalStorageWritable()) {
                    val pdfPath = "${requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)}/InformesAusuarios.pdf"
                    val file = File(pdfPath)

                    val writer = PdfWriter(FileOutputStream(file))
                    val pdf = PdfDocument(writer)
                    val document = Document(pdf)

                    document.add(Paragraph(usuarios.toString()))

                    document.close()
                    Toast.makeText(requireContext(), "Informe de usuarios guardado en $pdfPath", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "El almacenamiento no está disponible", Toast.LENGTH_SHORT).show()
                }
            } catch (e: IOException) {
                Toast.makeText(requireContext(), "Error al generar el informe PDF", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error inesperado: ${e.message}", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            }
        }
    }

    private fun isExternalStorageWritable(): Boolean {
        return Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED
    }

    private fun initializeViews(root: View) {
        textViewResumenConfiguracion = root.findViewById(R.id.textViewResumenConfiguracion)
        botonInforme = root.findViewById(R.id.botonInforme)
        radioOpcion2 = root.findViewById(R.id.radioOpcion2)
    }

    private fun setupListeners() {
        val textView = binding!!.textViewResumenConfiguracion
        galleryViewModel!!.text.observe(viewLifecycleOwner) { text: CharSequence? ->
            textView.text = text
        }

        botonInforme!!.setOnClickListener {
            generarInformePDF()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    generarInformePDF()
                } else {
                    Toast.makeText(requireContext(), "Permiso de escritura denegado", Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}