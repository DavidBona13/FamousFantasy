package com.example.famousfantasy_1.database

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.Inicio
import com.example.famousfantasy_1.R

class Registro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registro)

        val etNombre = findViewById<EditText>(R.id.et_user)
        val etMail = findViewById<EditText>(R.id.id_mail)
        val etUsuario = findViewById<EditText>(R.id.et_usuario)
        val etPass = findViewById<EditText>(R.id.id_pass)

        val btnAddUser = findViewById<Button>(R.id.btn_crear)


        btnAddUser.setOnClickListener {

            val nombre = etNombre.text.toString()
            val mail = etMail.text.toString()
            val usuario = etUsuario.text.toString()
            val pass = etPass.text.toString()

            //val regex = Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{6,}\$")
            val regex = Regex("^(?=(?:.*\\d){6,})(?=.*[a-z])(?=.*[A-Z]).*$")


            if (!pass.matches(regex)) {

                Toast.makeText(this, "La contraseña debe contener al menos 6 dígitos, una letra mayúscula y una minúscula.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val admin = BaseDatosApp(this, "bd", null, 1)
            val bd = admin.writableDatabase
            val reg = ContentValues()

            //reg.put("ID", 1)
            reg.put("NOMBRE", nombre)
            reg.put("MAIL", mail)
            reg.put("NOMBRE_USER", usuario)
            reg.put("PASSWORD", pass)

            bd.insert("Usuarios", null, reg)
            bd.close()
            Toast.makeText(this, "Registrando usuario...", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, Inicio::class.java)
            startActivity(intent)
        }
    }
    fun isValidPassword(password: String): Boolean {
        //val regex = Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{6,}$")
        val regex = Regex("^(?=(?:.*\\d){6,})(?=.*[a-z])(?=.*[A-Z]).*$")

        return password.matches(regex)
    }

}