package com.example.famousfantasy_1.ui.home

import android.annotation.SuppressLint
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.R
import com.example.famousfantasy_1.database.BaseDatosApp
import com.example.famousfantasy_1.databinding.FragmentHomeBinding
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry

class HomeFragment : Fragment() {
    private var binding: FragmentHomeBinding? = null
    private var textViewResumenConfiguracion: TextView? = null // Nuevo TextView
    private lateinit var barChart: BarChart

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val homeViewModel = ViewModelProvider(this).get(
            HomeViewModel::class.java
        )
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding!!.root

        // Obtener el BarChart del layout
        barChart = root.findViewById(R.id.homeBarChart) // Actualizado a homeBarChart

        // Inicializar el TextView
        textViewResumenConfiguracion = TextView(activity)

        // Configurar el TextView
        textViewResumenConfiguracion?.apply {
            text = "GRÁFICO DEL VALOR"
            textSize = 30f
            setTextColor(resources.getColor(R.color.rosado))
        }

        // Agregar el TextView al layout
        val params = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        (root as ViewGroup).addView(textViewResumenConfiguracion, params)

        // Obtener los datos de la base de datos y actualizar el gráfico de barras
        updateBarChart()

        return root
    }

    // Método para actualizar el gráfico de barras con los datos de la base de datos
    private fun updateBarChart() {
        var valoresFamosos = obtenerValoresFamosos()

        // Ordenar los datos de mayor a menor
        valoresFamosos = obtenerValoresFamosos().sortedDescending()

        // Crear las entradas para el gráfico de barras
        val entries = ArrayList<BarEntry>()
        for ((indice, valor) in valoresFamosos.withIndex()) {
            entries.add(BarEntry(indice.toFloat(), valor.toFloat()))
        }

        // Configurar el conjunto de datos
        val dataSet = BarDataSet(entries, "Valores de Famosos")
        dataSet.color = resources.getColor(R.color.white)

        // Configurar el eje X
        val xAxis = barChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setDrawGridLines(false)
        xAxis.granularity = 1f

        // Configurar el eje Y
        val yAxisLeft = barChart.axisLeft
        val yAxisRight = barChart.axisRight
        yAxisLeft.axisMinimum = 0f
        yAxisRight.axisMinimum = 0f

        // Crear y configurar el conjunto de datos del gráfico
        val barData = BarData(dataSet)
        barChart.data = barData
        barChart.setFitBars(true)
        barChart.description.isEnabled = false
        barChart.legend.isEnabled = false
        barChart.invalidate()
    }

    // Método para obtener los valores de los famosos de la base de datos
    @SuppressLint("Range")
    private fun obtenerValoresFamosos(): List<Double> {
        val baseDatos = BaseDatosApp(requireContext(), "bd", null, 1)
        val db = baseDatos.readableDatabase
        val valoresFamosos = mutableListOf<Double>()

        val query = "SELECT VALOR_VALOR FROM FamososMercado"
        val cursor: Cursor = db.rawQuery(query, null)
        while (cursor.moveToNext()) {
            val valor = cursor.getDouble(cursor.getColumnIndex("VALOR_VALOR"))
            valoresFamosos.add(valor)
        }
        cursor.close()
        db.close()

        return valoresFamosos
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
