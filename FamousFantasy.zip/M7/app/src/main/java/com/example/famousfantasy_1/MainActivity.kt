package com.example.famousfantasy_1

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.database.BaseDatosApp

class MainActivity : AppCompatActivity() {

    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var textViewValor: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.general)

        // Inicializar el MediaPlayer con el archivo de audio
        mediaPlayer = MediaPlayer.create(this, R.raw.general)
        // Comenzar la reproducción
        mediaPlayer.start()

        val boton1: ImageButton = findViewById(R.id.imageButton1)
        boton1.setOnClickListener {
            val notificacion = Toast.makeText(this@MainActivity, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }

        val button2: Button = findViewById(R.id.button4)
        val button3: Button = findViewById(R.id.button5)
        val button4: Button = findViewById(R.id.button6)
        val button5: Button = findViewById(R.id.button7)

        button2.setOnClickListener{
            lanzarEquipo(it)
        }

        button3.setOnClickListener{
            lanzarMercado(it)
        }

        button4.setOnClickListener{
            lanzarTabla(it)
        }

        button5.setOnClickListener{
            lanzarMas(it)
        }

        //actualizarDineroUsuario()

    }

    fun lanzarEquipo(view: View){
        mediaPlayer.stop() // Detener la reproducción cuando se lanza otra actividad
        val intent = Intent(this, Equipo::class.java)
        startActivity(intent)
    }

    fun lanzarMercado(view: View){
        mediaPlayer.stop() // Detener la reproducción cuando se lanza otra actividad
        val intent = Intent(this, Mercado::class.java)
        startActivity(intent)
    }

    fun lanzarTabla(view: View){
        mediaPlayer.stop() // Detener la reproducción cuando se lanza otra actividad
        val intent = Intent(this, Tabla::class.java)
        startActivity(intent)
    }

    fun lanzarMas(view: View){
        mediaPlayer.stop() // Detener la reproducción cuando se lanza otra actividad
        val intent = Intent(this, Mas::class.java)
        startActivity(intent)
    }

    override fun onPause() {
        super.onPause()
        // Pausar la reproducción del MediaPlayer cuando la actividad entra en pausa
        mediaPlayer.pause()
    }

    override fun onResume() {
        super.onResume()
        // Reanudar la reproducción del MediaPlayer cuando la actividad se reanuda
        mediaPlayer.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Liberar recursos del MediaPlayer cuando se destruye la actividad
        mediaPlayer.release()
    }
/*
    private fun actualizarDineroUsuario() {
        // Realizar la consulta a la base de datos para obtener el dinero del usuario
        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.readableDatabase
        val cursor = bd.rawQuery("SELECT DINERO FROM Usuarios", null)

        // Verificar si hay resultados y actualizar el texto del TextView
        if (cursor.moveToFirst()) {
            val dineroUsuario = cursor.getDouble(0)
            textViewValor.text = String.format("%.1f M", dineroUsuario)
        }

        // Cerrar el cursor y la conexión a la base de datos
        cursor.close()
        bd.close()
    }*/
}
