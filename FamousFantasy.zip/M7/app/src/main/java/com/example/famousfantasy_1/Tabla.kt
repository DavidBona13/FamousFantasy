package com.example.famousfantasy_1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.database.BaseDatosApp

class Tabla : AppCompatActivity() {

    private lateinit var textViewValor: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tabla)
        val boton7: ImageButton = findViewById(R.id.imageButton1)
        boton7.setOnClickListener {
            val notificacion = Toast.makeText(this@Tabla, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }
        val button1: Button = findViewById(R.id.btn_iniciar_sesionT)
        val button2: Button = findViewById(R.id.button4)
        val button3: Button = findViewById(R.id.button5)
        val button4: Button = findViewById(R.id.button7)
        val button5: Button = findViewById(R.id.button9)
        val button6: Button = findViewById(R.id.button10)

        button1.setOnClickListener{
            lanzarGeneral(it)
        }

        button2.setOnClickListener{
            lanzarEquipo(it)
        }

        button3.setOnClickListener{
            lanzarMercado(it)
        }

        button4.setOnClickListener{
            lanzarMas(it)
        }
        button5.setOnClickListener {
            lanzarClasificacionSemanal(it)
        }

        button6.setOnClickListener{
            lanzarClasificacionGeneral(it)
        }

        //actualizarDineroUsuario()

    }

    fun lanzarGeneral(view: View){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun lanzarEquipo(view: View){
        val intent = Intent(this, Equipo::class.java)
        startActivity(intent)
    }

    fun lanzarMercado(view: View){
        val intent = Intent(this, Mercado::class.java)
        startActivity(intent)
    }

    fun lanzarMas(view: View){
        val intent = Intent(this, Mas::class.java)
        startActivity(intent)
    }

    fun lanzarClasificacionGeneral(view: View){
        val intent = Intent(this, Clasificacion_general::class.java)
        startActivity(intent)
    }

    fun lanzarClasificacionSemanal(view: View){
        val intent = Intent(this, Clasificacion_semanal::class.java)
        startActivity(intent)
    }
/*
    private fun actualizarDineroUsuario() {
        // Realizar la consulta a la base de datos para obtener el dinero del usuario
        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.readableDatabase
        val cursor = bd.rawQuery("SELECT DINERO FROM Usuarios", null)

        // Verificar si hay resultados y actualizar el texto del TextView
        if (cursor.moveToFirst()) {
            val dineroUsuario = cursor.getDouble(0)
            textViewValor.text = String.format("%.1f M", dineroUsuario)
        }

        // Cerrar el cursor y la conexión a la base de datos
        cursor.close()
        bd.close()
    }*/
}