package com.example.famousfantasy_1.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.famousfantasy_1.R

class BaseDatosApp(context: Context?, name: String?, factory: SQLiteDatabase.CursorFactory?, version: Int)
    : SQLiteOpenHelper(context, name, factory, version) {

    val create_users_table = "CREATE TABLE Usuarios " +
            "(ID INTEGER PRIMARY KEY AUTOINCREMENT," +
            "NOMBRE TEXT, " +
            "MAIL TEXT, " +
            "NOMBRE_USER TEXT, " +
            "PASSWORD TEXT, " +
            "DINERO DOUBLE  DEFAULT 200000000)"

    val insert_data_table_user = "INSERT INTO Usuarios(ID, NOMBRE, MAIL, NOMBRE_USER, PASSWORD) VALUES (1, 'Daniel', 'Danielrb@gmail.com', 'dani721tiger' '1234')"

    val create_famosos_fichados ="CREATE TABLE FamososFichados" +
            "(ID INTEGER PRIMARY KEY, " +
            "NOMBRE TEXT, " +
            "DATOS TEXT, " +
            "VALOR TEXT, " +
            "IMAGEN_RUTA TEXT, " +
            "PUNTOS INT, " +
            "DESCRIPCION_IMAGEN TEXT)"

    //val rutaImagen = "/ruta/a/la/imagen.png"
    //val descripcion = "Imagen de ejemplo"
    //val insert_data_table_famosos_fichados = "INSERT INTO FamososFichados(ID, NOMBRE, DATOS, VALOR, IMAGEN_RUTA,DESCRIPCION_RUTA) VALUES (1, 'Mister Tartaria', 'Versiones por el espacio tiempo', '12.6M', " + "'" + rutaImagen +"', " + "'"+ descripcion+"' )"

    val create_famosos_mercado ="CREATE TABLE FamososMercado" +
            "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "AVATAR INT, " +
            "NOMBRE_FAMOSOS TEXT, " +
            "DATOS TEXT, " +
            "VALOR TEXT, " +
            "VAlOR_DATOS TEXT," +
            "VALOR_VALOR DOUBLE," +
            "IMAGEN_FLECHA INT," +
            "BOTON INT, " +
            "USER INT)"


    //val insert_data_table_famosos_mercado = "INSERT INTO FamososFichados(ID, NOMBRE, DATOS, VALOR, IMAGEN_RUTA,DESCRIPCION_RUTA) VALUES (1, 'Mister Tartaria', 'Superviviente del reset del ¿1798?', 12.6, " + "'" + rutaImagen +"', " + "'"+ descripcion+"' )"

    val create_valor = "CREATE TABLE Valor" +
            "(ID INTEGER PRIMARY KEY, " +
            "VALOR_GENERAL DOUBLE)"

    val insert_data_table_valor ="INSERT INTO Valor(ID, VALOR_GENERAL) VALUES (1, 24.8)"

    val create_semanal = "CREATE TABLE Semanal" +
            "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "IMAGEN_POSICION TEXT, " +
            "NOM_USER TEXT, " +
            "PUNTOS INT)"

    val create_general = "CREATE TABLE General" +
            "(ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "IMAGEN_POSICION TEXT, " +
            "NOM_USER TEXT, " +
            "PUNTOS INT)"

    override fun onCreate(database: SQLiteDatabase?) {

        if (database != null) {
            database.execSQL(create_users_table)
        }
        if (database != null) {
            database.execSQL(create_famosos_mercado)
        }
        if (database != null) {
            database.execSQL(create_valor)
        }

        if (database != null) {
            database.execSQL(create_famosos_fichados)
        }

        if (database != null) {
            database.execSQL(create_semanal)
        }

        if (database != null) {
            database.execSQL(create_general)
        }

        if (database != null){
            database.execSQL(insert_data_table_famosos_mercado)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }

    val insert_data_table_famosos_mercado = "INSERT INTO FamososMercado(AVATAR, NOMBRE_FAMOSOS, DATOS, VALOR, VALOR_DATOS, VALOR_VALOR, IMAGEN_FLECHA, BOTON, USER) VALUES " +
            "("+ R.mipmap.ic_will_smith+", 'Will smith', 'datos:', 'valor:', 'Buen golpeo', '23.682.219'," + R.drawable.flecha_abajo+ ", 1, 1), " +
            "("+ R.mipmap.ic_abalos+", 'Ábalos', 'datos:', 'valor:', 'no pierde la marca', '17.223.029'," + R.drawable.flecha_arriba + ", 1, 1), " +
            "("+ R.mipmap.ic_arianna_grande+", 'Ariana Grande', 'datos:', 'valor:', 'infalible en el suelo', '31.093.772'," + R.drawable.flecha_abajo+ ", 1, 1), " +
            "("+ R.mipmap.ic_lamine_yamal+", 'Lamine Yamal', 'datos:', 'valor:', 'estudiante', '42.603.428'," + R.drawable.flecha_arriba+ ", 1, 1), " +
            "("+ R.mipmap.ic_david_broncano+", 'David Broncano', 'datos:', 'valor:', 'corredor', '21,811.320'," + R.drawable.flecha_arriba + ", 1, 1), " +
            "("+ R.mipmap.ic_mariano_rajoy+", 'Mariano Rajoy', 'datos: ', 'valor: ','gallego', '21.553.142'," + R.drawable.flecha_abajo+ ",  1, 1 ), " +
            "("+ R.mipmap.ic_pedro_sanchez+", 'Pedro Sanchez', 'datos: ', 'valor: ','impredecible', '55.701.623'," + R.drawable.flecha_arriba+ ",  1, 1 ), " +
            "("+ R.mipmap.ic_mariah_carey+", 'Mariah Carey', 'datos: ', 'valor: ','misma jugada', '11.053.155'," + R.drawable.flecha_abajo + ",  1, 1 ), " +
            "("+ R.mipmap.ic_papa_de_roma+", 'Papa de roma', 'datos: ', 'valor: ','superviviente', '6.993.002'," + R.drawable.flecha_abajo + ",  1, 1 ), " +
            "("+ R.mipmap.ic_ben_affleck+", 'Ben Affleck', 'datos: ', 'valor: ','vino frances', '15.664.921'," + R.drawable.flecha_abajo + ",  1, 1 ), " +
            "("+ R.mipmap.ic_luuk_de_jong+", 'Luuk de jong', 'datos: ', 'valor: ','superclase', '4.937.088'," + R.drawable.flecha_abajo+ ",  1, 1 ), " +
            "("+ R.mipmap.ic_xavi_hernandez+", 'Xavi hernandez', 'datos: ', 'valor: ','si pero no', '29.644.211'," + R.drawable.flecha_arriba+ ",  1, 1 ), " +
            "("+ R.mipmap.ic_taylor_swift+", 'Taylor swift', 'datos: ', 'valor: ','mamporrera', '77.206.989'," + R.drawable.flecha_arriba+ ",  1, 1 );"


}
