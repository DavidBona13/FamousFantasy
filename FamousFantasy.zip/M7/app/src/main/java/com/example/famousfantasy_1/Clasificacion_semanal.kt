package com.example.famousfantasy_1

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.database.BaseDatosApp

class Clasificacion_semanal : AppCompatActivity() {
    private lateinit var textViewValor: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.clasificacion_semanal)
        val boton7: ImageButton = findViewById(R.id.imageButton1)
        boton7.setOnClickListener {
            val notificacion = Toast.makeText(this@Clasificacion_semanal, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }
        //actualizarDineroUsuario()

    }
/*
    private fun actualizarDineroUsuario() {
        // Realizar la consulta a la base de datos para obtener el dinero del usuario
        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.readableDatabase
        val cursor = bd.rawQuery("SELECT DINERO FROM Usuarios", null)

        // Verificar si hay resultados y actualizar el texto del TextView
        if (cursor.moveToFirst()) {
            val dineroUsuario = cursor.getDouble(0)
            textViewValor.text = String.format("%.1f M", dineroUsuario)
        }

        // Cerrar el cursor y la conexión a la base de datos
        cursor.close()
        bd.close()
    }*/
}