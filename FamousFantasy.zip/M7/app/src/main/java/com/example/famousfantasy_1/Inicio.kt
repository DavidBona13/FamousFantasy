package com.example.famousfantasy_1

import android.annotation.SuppressLint
import android.content.Intent
import android.content.Intent.EXTRA_USER
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.famousfantasy_1.database.BaseDatosApp
import com.example.famousfantasy_1.database.Registro

class Inicio : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.inicio)

        val btnIniciar : Button = findViewById(R.id.btn_iniciar_sesionT)
        val btnRegistrar : Button = findViewById(R.id.btn_register)

        /*btnIniciar.setOnClickListener{
            iniciarSesion(it)
        }*/

        btnRegistrar.setOnClickListener{
            lanzarRegistrer(it)
        }
    }

    fun lanzarRegistrer(view: View){
        val intent = Intent(this, Registro::class.java)
        startActivity(intent)
    }

    fun iniciarSesion(view: View) {
        val etUsuario : EditText = findViewById(R.id.et_user)
        val etPassword : EditText = findViewById(R.id.et_pass)

        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.writableDatabase
        val fila = bd.rawQuery("SELECT NOMBRE_USER, PASSWORD FROM Usuarios WHERE NOMBRE='${etUsuario.text}' AND PASSWORD='${etPassword.text}'", null)
        var user = ""
        var password = ""
        if(fila.moveToFirst()){
            user = fila.getString(0)
            password = fila.getString(1)
        }

        if(etUsuario.text.toString().equals(user)) {
            if(etPassword.text.toString().equals(password)){
                Toast.makeText(this, "Iniciando sesion...", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra(EXTRA_USER, user)
                }
                startActivity(intent)
            }
        } else {
            Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
        }

    }

}