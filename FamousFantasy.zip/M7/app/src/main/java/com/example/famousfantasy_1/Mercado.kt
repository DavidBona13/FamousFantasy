package com.example.famousfantasy_1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.famousfantasy_1.Data.Tarea
import com.example.famousfantasy_1.controller.AdapterTareas
import com.example.famousfantasy_1.database.BaseDatosApp

class Mercado : AppCompatActivity() {

    private lateinit var adapterTareas: AdapterTareas
    private lateinit var recyclerView: RecyclerView
    private lateinit var textViewValor: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mercado)
        val boton7: ImageButton = findViewById(R.id.imageButton1)
        boton7.setOnClickListener {
            val notificacion = Toast.makeText(this@Mercado, "MENU DE CONFIGURACION", Toast.LENGTH_SHORT)
            notificacion.show()
            val intencion = Intent(applicationContext, MenuSlide::class.java)
            startActivity(intencion)
        }

        val button1: Button = findViewById(R.id.btn_iniciar_sesionT)
        val button2: Button = findViewById(R.id.button4)
        val button3: Button = findViewById(R.id.button6)
        val button4: Button = findViewById(R.id.button7)

        button1.setOnClickListener{
            lanzarGeneral(it)
        }

        button2.setOnClickListener{
            lanzarEquipo(it)
        }

        button3.setOnClickListener{
            lanzarTabla(it)
        }

        button4.setOnClickListener{
            lanzarMas(it)
        }

        //actualizarDineroUsuario()

    }

    override fun onStart() {
        super.onStart()
        //val contextoAdaptadorTareas = adapterTareas.obtenerContext()
        val layoutManager = LinearLayoutManager(this)
        recyclerView = findViewById(R.id.llista_tareas2)
        recyclerView.layoutManager = layoutManager
        recyclerView.setHasFixedSize(true)
        adapterTareas = AdapterTareas(getTareasList())
        recyclerView.adapter = adapterTareas
    }

    fun getTareasList() : ArrayList<Tarea>{
        var tareasList : ArrayList<Tarea> = ArrayList()
        /*
                tareasList.add(Tarea(1, R.mipmap.ic_launcher_round, "Ariana Grande", "datos: ", "valor: ","escurridiza", "29.089.342", R.mipmap.ic_launcher_round, mostrarButton = true, 1 ))
                tareasList.add(Tarea(2, R.mipmap.ic_launcher_round, "Will Smith", "datos: ", "valor: ","buen golpeo", "13.735.023", R.mipmap.ic_launcher_round, mostrarButton = true, 1 ))
                tareasList.add(Tarea(3, R.mipmap.ic_launcher_round, "Mariano Rajoy", "datos: ", "valor: ","gallego", "21.553.142", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(4, R.mipmap.ic_launcher_round, "Pedro Sanchez", "datos: ", "valor: ","impredecible", "55.701.623", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(5, R.mipmap.ic_launcher_round, "Mariah Carey", "datos: ", "valor: ","misma jugada", "11.053.155", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(6, R.mipmap.ic_launcher_round, "Papa de roma", "datos: ", "valor: ","superviviente", "6.993.002", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(7, R.mipmap.ic_launcher_round, "Ben Affleck", "datos: ", "valor: ","vino frances", "15.664.921", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(8, R.mipmap.ic_launcher_round, "Luuk de jong", "datos: ", "valor: ","superclase", "4.937.088", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(9, R.mipmap.ic_launcher_round, "Xavi hernandez", "datos: ", "valor: ","si pero no", "29.644.211", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
                tareasList.add(Tarea(10, R.mipmap.ic_launcher_round, "Taylor swift", "datos: ", "valor: ","mamporrera", "77.206.989", R.mipmap.ic_launcher_round,  mostrarButton = true, 1 ))
        */
        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.writableDatabase

        val reg = bd.rawQuery("SELECT ID, AVATAR, NOMBRE_FAMOSOS, DATOS, VALOR, VALOR_DATOS, VALOR_VALOR, IMAGEN_FLECHA, BOTON, USER FROM FamososMercado;", null)
        var id = 0;
        var avatar = "";
        var nombre_famoso = "";
        var datos = "";
        var valor = "";
        var valor_datos = "";
        var valor_valor = "";
        var imagen_flecha = 0;
        var boton = 0;
        var user = 0;

        if (reg.moveToFirst()){
            do {
                id = reg.getString(0).toInt()
                avatar = reg.getString(1).toInt().toString()
                nombre_famoso = reg.getString(2)
                datos = reg.getString(3)
                valor = reg.getString(4)
                valor_datos = reg.getString(5)
                valor_valor = reg.getString(6)
                imagen_flecha = reg.getString(7).toInt()
                boton = reg.getString(8).toInt()
                user = reg.getString(9).toInt()
                if (boton == 1){
                    tareasList.add(Tarea(id, avatar.toInt(), nombre_famoso, datos, valor, valor_datos, valor_valor, imagen_flecha, true, user))
                }

            } while (reg.moveToNext())
        }
        return tareasList
    }

    fun lanzarGeneral(view: View){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun lanzarEquipo(view: View){
        val intent = Intent(this, Equipo::class.java)
        startActivity(intent)
    }

    fun lanzarTabla(view: View){
        val intent = Intent(this, Tabla::class.java)
        startActivity(intent)
    }

    fun lanzarMas(view: View){
        val intent = Intent(this, Mas::class.java)
        startActivity(intent)
    }
/*
    private fun actualizarDineroUsuario() {
        // Realizar la consulta a la base de datos para obtener el dinero del usuario
        val admin = BaseDatosApp(this, "bd", null, 1)
        val bd = admin.readableDatabase
        val cursor = bd.rawQuery("SELECT DINERO FROM Usuarios", null)

        // Verificar si hay resultados y actualizar el texto del TextView
        if (cursor.moveToFirst()) {
            val dineroUsuario = cursor.getDouble(0)
            textViewValor.text = String.format("%.1f M", dineroUsuario)
        }

        // Cerrar el cursor y la conexión a la base de datos
        cursor.close()
        bd.close()
    }*/

}