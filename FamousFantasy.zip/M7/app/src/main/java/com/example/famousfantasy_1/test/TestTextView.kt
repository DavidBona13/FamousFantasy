package com.example.famousfantasy_1.test

import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.R
import com.example.famousfantasy_1.database.Registro
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class TestTextView {
    @get:Rule
    val activityScenarioRule = ActivityScenarioRule(MainActivity::class.java)
    @Test
    fun testTitleTextView() {
        val expectedText = "Nuevos eventos... "
        val scenario = activityScenarioRule.scenario
        scenario.onActivity { activity ->
            val textView = activity.findViewById<TextView>(R.id.textView8)
            val actualText = textView.text.toString()
            assertEquals(expectedText, actualText)
        }
    }


    @Test
    fun testTextView23Text() {
        val expectedText = "La caballeria pesada ya está aquí"

        activityScenarioRule.scenario.onActivity { activity ->
            val textView = activity.findViewById<TextView>(R.id.textView23)
            assertNotNull(textView)
            assertEquals(expectedText, textView.text.toString())
        }
    }
}