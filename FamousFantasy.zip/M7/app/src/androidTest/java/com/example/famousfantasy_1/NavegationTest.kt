package com.example.famousfantasy_1
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class NavegationTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun testNavigation() {

        // Verifica que el layout general està mostrant-se inicialment
        onView(withId(R.id.general)).check(matches(isDisplayed()))

        // Navega al layout de Equipo
        onView(withId(R.id.button4)).perform(click())
        onView(withId(R.id.linearLayout)).check(matches(isDisplayed()))

        // torna al layout general
        onView(withId(R.id.btn_iniciar_sesionT)).perform(click())
        onView(withId(R.id.general)).check(matches(isDisplayed()))

        // Navega al layout de Mercado
        onView(withId(R.id.button5)).perform(click())
        onView(withId(R.id.mercado)).check(matches(isDisplayed()))

        // torna al layout general
        onView(withId(R.id.btn_iniciar_sesionT)).perform(click())
        onView(withId(R.id.general)).check(matches(isDisplayed()))

        // Navega al layout tabla
        onView(withId(R.id.button6)).perform(click())
        onView(withId(R.id.tabla)).check(matches(isDisplayed()))

        //retorna al layout general
        onView(withId(R.id.btn_iniciar_sesionT)).perform(click())
        onView(withId(R.id.general)).check(matches(isDisplayed()))
    }
}