package com.example.famousfantasy_1

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.typeText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InicioTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(Inicio::class.java)

    @Test
    fun testUserCanEnterTextInFields() {

        //usuari que existeixi
        onView(withId(R.id.et_user))
            .perform(typeText("mar00"), ViewActions.closeSoftKeyboard());

        // Escriu la contrasenya que existeixi
        onView(withId(R.id.et_pass))
            .perform(typeText("112233Aa"), ViewActions.closeSoftKeyboard());

        // Botó d'iniciar sessió
        onView(withId(R.id.btn_iniciar_sesionT))
            .perform(click())

        // Comproba que es mou de layout
        onView(withId(R.id.general))
            .check(matches(isDisplayed()))
    }
}