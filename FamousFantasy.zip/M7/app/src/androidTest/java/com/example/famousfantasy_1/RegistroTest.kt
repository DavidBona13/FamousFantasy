package com.example.famousfantasy_1

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.famousfantasy_1.database.Registro
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RegistroTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(Registro::class.java)

    @Test
    fun testRegistro() {

        // nom d'usuari
        onView(withId(R.id.et_user))
            .perform(typeText("mar"), closeSoftKeyboard())

        // correu electrònic
        onView(withId(R.id.id_mail))
            .perform(typeText("prueba@example.com"), closeSoftKeyboard())

        // nom del joc de l'usuari
        onView(withId(R.id.et_usuario))
            .perform(typeText("mar00"), closeSoftKeyboard())

        // contrasenya amb els 6 números, 1 lletra majúscula i una minúscula
        onView(withId(R.id.id_pass))
            .perform(typeText("112233Aa"), closeSoftKeyboard())

        // Fer click al botó registre
        onView(withId(R.id.btn_crear))
            .perform(click())

        // Comproba si és mou de layout
        onView(withId(R.id.inicio))
            .check(matches(isDisplayed()))
    }

}