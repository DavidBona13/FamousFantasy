package com.example.famousfantasy_1.Data

import android.widget.Button

data class Tarea (
    var id: Int,
    var foto: Int,
    var famoso: String,
    var datos: String,
    var valor: String,
    var valorDatos: String,
    var valorValor: String,
    var flecha: Int,
    var mostrarButton : Boolean,
    var user: Int
    )