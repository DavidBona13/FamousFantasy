package com.example.famousfantasy_1.ui.slideshow
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.VideoView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.famousfantasy_1.MainActivity
import com.example.famousfantasy_1.R
import com.example.famousfantasy_1.databinding.FragmentSlideshowBinding

class SlideshowFragment : Fragment() {
    private var binding: FragmentSlideshowBinding? = null
    private var videoView: VideoView? = null
    private var mediaController: MediaController? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val slideshowViewModel = ViewModelProvider(this).get(SlideshowViewModel::class.java)
        binding = FragmentSlideshowBinding.inflate(inflater, container, false)
        val root: View = binding!!.root
        val textView = binding!!.textViewResumenConfiguracion
        val buttonGuardar = binding!!.botonGuardar
        videoView = binding!!.videoprueba

        // Configurar el texto
        textView.text =
            "Famous Fantasy te ofrece una experiencia única para seguir de cerca a tus famosos favoritos, combinando emoción y entretenimiento. Con un equipo apasionado y una comunidad global, nuestro objetivo es sumergirte en el fascinante mundo del famoso fantasy, donde la transparencia y la equidad son nuestros pilares. Trabajamos incansablemente para mejorar y expandir la plataforma, ¡únete a nosotros y construyamos momentos inolvidables juntos en Famous Fantasy!"

        // Configurar el botón
        buttonGuardar.setOnClickListener { launchGeneralActivity() }

        // Configurar el video
        val uri = Uri.parse("android.resource://" + requireActivity().packageName + "/" + R.raw.videoprueba)
        videoView?.setVideoURI(uri)
        videoView?.start()

        // Configurar el MediaController
        mediaController = MediaController(requireContext())
        mediaController?.setAnchorView(videoView)
        videoView?.setMediaController(mediaController)

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
        videoView = null
        mediaController = null
    }

    // Método para la acción del botón (puedes ajustar esto según tus necesidades)
    private fun launchGeneralActivity() {
        val intent = Intent(activity, MainActivity::class.java)
        startActivity(intent)
    }
}
