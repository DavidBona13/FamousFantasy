package com.example.famousfantasy_1.test

import android.widget.EditText
import com.example.famousfantasy_1.database.Registro
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordValidationTest {
    @Test
    fun testPasswordValidation() {
        // Casos de prueba para la validación de contraseña
        assertTrue(validatePassword("Password1")) // Cumple con los requisitos
        assertTrue(validatePassword("Password123")) // Cumple con los requisitos
        assertTrue(validatePassword("Abcdefg1")) // Cumple con los requisitos

        assertFalse(validatePassword("123456")) // No contiene letras
        assertFalse(validatePassword("abcdef")) // No contiene letras mayúsculas
        assertFalse(validatePassword("ABCDEFG")) // No contiene letras minúsculas
        assertFalse(validatePassword("Abcdef")) // No contiene números
        assertFalse(validatePassword("Abc")) // Menos de 6 caracteres
    }

    private fun validatePassword(password: String): Boolean {
        return Registro().isValidPassword(password)
    }
}